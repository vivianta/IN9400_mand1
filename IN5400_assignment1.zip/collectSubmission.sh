rm -f IN5400_assignment1.zip 
zip -r IN5400_assignment1.zip . -x    "*.ipynb_checkpoints
*" ".env/*"
